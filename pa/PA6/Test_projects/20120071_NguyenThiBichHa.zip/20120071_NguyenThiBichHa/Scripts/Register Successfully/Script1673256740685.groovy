import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('http://127.0.0.1:8000/login/?next=/')

WebUI.click(findTestObject('Object Repository/Page_SIGN IN/a_Register now'))

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__username'), 'bichha123')

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__email'), 'realmin94@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password1'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password2'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/button_SIGN Up'))

WebUI.click(findTestObject('Object Repository/Page_SIGN IN/a_Register now'))

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/div_Username    Required. 150 characters or_7598cf'))

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__username'), 'sonha123')

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__email'), 'shakeke@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password1'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password2'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/button_SIGN Up'))

WebUI.click(findTestObject('Object Repository/Page_SIGN IN/a_Register now'))

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__username'), 'anpt2002')

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__email'), 'anptkeke@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password1'), '1R+g7stitcY2Zxyz243yEg==')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password2'), '1R+g7stitcY2Zxyz243yEg==')

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/button_SIGN Up'))

WebUI.click(findTestObject('Object Repository/Page_SIGN IN/a_Register now'))

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__username'), 'kduy123456')

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__email'), 'kduykeke@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password1'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password2'), 'B/3r7oxiyl8BefahoXh7Wg==')

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/button_SIGN Up'))

WebUI.click(findTestObject('Object Repository/Page_SIGN IN/a_Register now'))

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__username'), 'bhashacute123')

WebUI.setText(findTestObject('Object Repository/Page_SIGN UP/input__email'), 'bhashakeke@gmail.com')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password1'), 'RSzey1hDPro2XVUIq4Ynjg==')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_SIGN UP/input__password2'), 'RSzey1hDPro2XVUIq4Ynjg==')

WebUI.click(findTestObject('Object Repository/Page_SIGN UP/button_SIGN Up'))

