<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Hello Welcome to ToDo web for study SIG_455495</name>
   <tag></tag>
   <elementGuidId>25aedeeb-3683-4e50-986b-816c75a66fc7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.container-login100</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>749d7252-899b-42b6-a641-dbf79271fbe8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>container-login100</value>
      <webElementGuid>d339c0e7-c213-4697-9a02-e936e4c933b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			
		</value>
      <webElementGuid>b8a4a02e-d1dc-4df9-8dce-212e886e2797</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;limiter&quot;]/div[@class=&quot;container-login100&quot;]</value>
      <webElementGuid>6fbcf927-e39b-43ad-88da-65aef3b867ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>0dc40c19-13d8-45be-a660-390f38f32e05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
			
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			
		' or . = '
			
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			
		')]</value>
      <webElementGuid>2e2733d7-b781-43de-aa7b-0c555e7a16b2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
