<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Hello Welcome to ToDo web for study SIG_455495_1</name>
   <tag></tag>
   <elementGuidId>33bd8b22-30a4-45ab-8121-b8f0116b3f0f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.wrap-login100</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1b264cf9-4902-453b-a241-b8d5d8b08645</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>wrap-login100</value>
      <webElementGuid>05040890-dbaa-463c-adda-5d2c203ac0e9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			</value>
      <webElementGuid>a28302cf-7741-4982-8cff-a5fc1ec6a645</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;limiter&quot;]/div[@class=&quot;container-login100&quot;]/div[@class=&quot;wrap-login100&quot;]</value>
      <webElementGuid>6a5c8f9f-1a05-47d7-81b3-b7a6d46aa86c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div</value>
      <webElementGuid>b72ad72d-3fa0-4e87-9998-ee9035b99088</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			' or . = '
				
					
					
						
					
					
						Hello
					
					
						 Welcome to ToDo web for study SIGN UP to get started.
					
				
					

					

					
					
				    
					

 
                Username*    A user with that username already exists. Required. 150 characters or fewer. Letters, digits and @/./+/-/_ only.    
                Email*       
                Password*    Your password can’t be too similar to your other personal information.Your password must contain at least 8 characters.Your password can’t be a commonly used password.Your password can’t be entirely numeric.    
                Password confirmation*    Enter the same password as before, for verification.  


					
						
							
							
								SIGN Up
							
						
					
					


					
						
							Already have an account ?
						

						
							Log in
						
					
				
			')]</value>
      <webElementGuid>ab203795-c456-477c-97df-dbe68bda458d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
