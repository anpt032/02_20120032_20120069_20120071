<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_SIGN Up</name>
   <tag></tag>
   <elementGuidId>f7761ad6-6921-4233-97da-ce0dda5641e2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.login100-form-btn</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>75e99135-5b5a-488c-aa3a-c6e88bd8b4d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>login100-form-btn</value>
      <webElementGuid>cb0a191f-e375-4bf4-a074-56843ccde404</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>a380868f-11d5-47b1-817d-ef4b7c545bce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
								SIGN Up
							</value>
      <webElementGuid>b1f35b31-f8cf-4131-8ff0-503f118f5b24</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;limiter&quot;]/div[@class=&quot;container-login100&quot;]/div[@class=&quot;wrap-login100&quot;]/form[@class=&quot;login100-form validate-form&quot;]/div[@class=&quot;container-login100-form-btn&quot;]/div[@class=&quot;wrap-login100-form-btn&quot;]/button[@class=&quot;login100-form-btn&quot;]</value>
      <webElementGuid>1afa7f65-e3f3-4129-95cb-b892ea7cf21e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='submit']</value>
      <webElementGuid>b07809c4-3d1b-4e7e-92f2-474ed7d26603</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter the same password as before, for verification.'])[1]/following::button[1]</value>
      <webElementGuid>aea15455-763e-4ec6-8608-5fafa3a4cbab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[4]/following::button[1]</value>
      <webElementGuid>a66ec389-2cf9-4ef0-b806-be9dc6471c58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Already have an account ?'])[1]/preceding::button[1]</value>
      <webElementGuid>362ee28a-c0a0-4710-b06d-e59589e2195b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log in'])[1]/preceding::button[1]</value>
      <webElementGuid>e186c4ce-e6c3-4958-b9ed-1737b1e233af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='SIGN Up']/parent::*</value>
      <webElementGuid>11d9c136-fce1-4f0d-ba77-104ac4abc958</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button</value>
      <webElementGuid>bb202d2a-d11a-4bd5-9ebe-f99633561a72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'submit' and (text() = '
								SIGN Up
							' or . = '
								SIGN Up
							')]</value>
      <webElementGuid>2df4473d-f44e-4a4e-91ed-632ca3ab2012</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
