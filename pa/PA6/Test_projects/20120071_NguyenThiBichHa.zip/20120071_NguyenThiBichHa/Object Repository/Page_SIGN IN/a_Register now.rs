<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Register now</name>
   <tag></tag>
   <elementGuidId>643ae727-1586-4998-aef8-cfb32ce6ca4e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.txt2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Register now')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7d12b112-9a4e-472c-b219-dcde3c3f9af9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>txt2</value>
      <webElementGuid>1e3ee984-b4aa-4405-90f3-0f475305e364</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/register</value>
      <webElementGuid>25e3fec4-5421-45bf-97b8-c0262953bba8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
							Register now
						</value>
      <webElementGuid>e310a523-504f-41bd-b450-46d40bce47f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;limiter&quot;]/div[@class=&quot;container-login100&quot;]/div[@class=&quot;wrap-login100&quot;]/form[@class=&quot;form-group&quot;]/div[@class=&quot;text-center p-t-80&quot;]/a[@class=&quot;txt2&quot;]</value>
      <webElementGuid>43b27919-665a-45a4-a638-2c95e0f27ae1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Register now')]</value>
      <webElementGuid>b77155fe-0768-4ae7-8ecb-b15bcd791d2b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Not a member ?'])[1]/following::a[1]</value>
      <webElementGuid>63d71869-e1a1-4d7a-aaa1-a59a1c806266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SIGN IN'])[2]/following::a[1]</value>
      <webElementGuid>2f7b6774-a921-4d5e-9258-d548d0089b99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Register now']/parent::*</value>
      <webElementGuid>31c834f4-d2d4-4f05-b980-da928b92def2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/register')]</value>
      <webElementGuid>66a3a6ce-4ec7-4ae9-ad2e-9c090517648e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a</value>
      <webElementGuid>70a4f273-df09-48cf-9538-7a4a32094f8d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/register' and (text() = '
							Register now
						' or . = '
							Register now
						')]</value>
      <webElementGuid>1dbd90e7-8ea7-4f19-ac90-f0f4afcb74f6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
