<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ToDo Lists</name>
   <tag></tag>
   <elementGuidId>08f2681f-9026-43d5-804a-94dbf2d2988e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar']/ul/li/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0e69c102-c7e3-4e6e-8c1d-7a99028d879c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/view</value>
      <webElementGuid>b0f85b9d-33aa-41ba-ac3e-cf9b9298fd18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> ToDo Lists</value>
      <webElementGuid>4a7d557e-4f89-44ad-82dc-25927ce7ddc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar&quot;)/ul[@class=&quot;list-unstyled components&quot;]/li[1]/a[1]</value>
      <webElementGuid>0cf0df62-6fea-4841-8028-64b50786c606</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar']/ul/li/a</value>
      <webElementGuid>ac71c04e-3ba1-4c83-8d1c-f88def240608</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search'])[1]/following::a[1]</value>
      <webElementGuid>f81b65cf-697a-48ec-bbcd-f86cb2fdc5e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TODAY:'])[1]/following::a[1]</value>
      <webElementGuid>c848fe0d-0907-4d54-be84-59124afbc638</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notes'])[1]/preceding::a[1]</value>
      <webElementGuid>306c7929-d679-4f6d-a180-ef353b3e8153</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/view')]</value>
      <webElementGuid>e6391d30-78ec-4766-ae53-0dadd9f0b3ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>3ddb1127-3b67-4b34-a577-4966f72fdbc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/view' and (text() = ' ToDo Lists' or . = ' ToDo Lists')]</value>
      <webElementGuid>3bf0eb0d-7f31-4fa8-b5bd-a4ddba5c83e9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
