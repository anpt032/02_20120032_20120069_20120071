<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Note 2</name>
   <tag></tag>
   <elementGuidId>dffcd291-5a49-442d-96f2-3625abb449cd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Note 2')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>916f4c04-59e2-469a-ac57-0b4444b619ec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=23</value>
      <webElementGuid>61597c8a-2886-4c1a-a8d7-446d64357939</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Note 2</value>
      <webElementGuid>f1babbc0-c11a-4173-ae4c-95d02711f709</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-2&quot;]/aside[@class=&quot;menu&quot;]/ul[@class=&quot;menu-list&quot;]/li[2]/a[1]</value>
      <webElementGuid>9578acef-0b9e-4cc1-89bf-15beba11c73d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Note 2')]</value>
      <webElementGuid>af440c04-f107-420b-b28b-87b60dda826c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 1'])[1]/following::a[1]</value>
      <webElementGuid>5da6e983-bdf8-450d-a265-fa9ee951e306</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New document'])[1]/following::a[2]</value>
      <webElementGuid>b147a9e1-c76b-4f6f-b17e-68f602d2ce2f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 3'])[1]/preceding::a[1]</value>
      <webElementGuid>4ba0deff-f9a0-4944-8391-bba021ab5fa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 4'])[1]/preceding::a[2]</value>
      <webElementGuid>e259d2ea-438c-4e52-badf-57d0c2aade12</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Note 2']/parent::*</value>
      <webElementGuid>f522b805-3e1f-48c8-88cc-7f49ab4881cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=23')]</value>
      <webElementGuid>4c856ad1-e263-410c-9861-b5e47ed093d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a</value>
      <webElementGuid>397c96c8-9024-4414-836f-e4de810760a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=23' and (text() = 'Note 2' or . = 'Note 2')]</value>
      <webElementGuid>80a41b71-9aa5-4575-b29a-0ec2a1228d33</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
