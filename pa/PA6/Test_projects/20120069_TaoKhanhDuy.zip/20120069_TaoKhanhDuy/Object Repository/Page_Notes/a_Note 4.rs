<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Note 4</name>
   <tag></tag>
   <elementGuidId>6e00c166-34df-4b4f-9eef-b7176b3147c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Note 4')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>57c58a41-db3c-455c-9444-86b54d7b5b15</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=25</value>
      <webElementGuid>c8db105a-709b-4fff-aec8-938c256c98a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Note 4</value>
      <webElementGuid>e86dfb12-6ac8-48e6-8106-8f7a6bdd210c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-2&quot;]/aside[@class=&quot;menu&quot;]/ul[@class=&quot;menu-list&quot;]/li[4]/a[1]</value>
      <webElementGuid>53d05d67-b7ac-4f68-aebf-168f1f748449</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Note 4')]</value>
      <webElementGuid>7b94bc18-6fa7-4782-8c38-c6e2a76ba06b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 3'])[1]/following::a[1]</value>
      <webElementGuid>0a117513-689c-4512-be9f-aeb2e6eb1f91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 2'])[1]/following::a[2]</value>
      <webElementGuid>e4165409-0452-400e-b1e5-7f571b1067dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 5'])[1]/preceding::a[1]</value>
      <webElementGuid>91029ea9-6e74-462f-86b1-c5b4c7667eb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Note 4']/parent::*</value>
      <webElementGuid>9a183805-89d2-438b-bcc3-f0f74da88408</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=25')]</value>
      <webElementGuid>2fc992b0-7205-4f23-afd5-0eb54a9ef70a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/a</value>
      <webElementGuid>ea01d930-2823-4995-b9d3-952f9a392196</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=25' and (text() = 'Note 4' or . = 'Note 4')]</value>
      <webElementGuid>bbf453e5-f8af-4d1c-838a-1886424d5563</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
