<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Title                                  _329ac9</name>
   <tag></tag>
   <elementGuidId>707408a4-0ce3-48df-b994-d9e356cc4b21</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.column.is-10</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 5'])[1]/following::div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e18c3b9d-d30f-463a-a931-ea0244f7d121</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>column is-10</value>
      <webElementGuid>1ea85448-3f99-4eb8-bf16-936d36b5996a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    
                        

                        

                        
                            
                                Title

                                
                                    
                                        Created at: 01/09 2023 / 
                                        Modified at: 01/09 2023
                                        
                                    
                                
                            
                            
                            
                                Public
                                
                                    
                                
                            
                            
                                
                            
                        

                        
                            Content

                            
                                
                            
                        

                        
                            
                                Save
                            
                            
                                
                                    Delete
                                
                            
                        
                    
                </value>
      <webElementGuid>c07f342a-b4b3-440a-93e7-9cc43fc96243</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-10&quot;]</value>
      <webElementGuid>82046e07-c162-494d-9958-d8f6d350c774</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 5'])[1]/following::div[1]</value>
      <webElementGuid>f3ca2381-216f-4883-878b-e7270d2a0763</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 4'])[1]/following::div[1]</value>
      <webElementGuid>619700e8-1897-41db-b13f-ec7abae88600</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]</value>
      <webElementGuid>b5ac678e-038c-49ac-bb3b-8c349b2c0bf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                    
                        

                        

                        
                            
                                Title

                                
                                    
                                        Created at: 01/09 2023 / 
                                        Modified at: 01/09 2023
                                        
                                    
                                
                            
                            
                            
                                Public
                                
                                    
                                
                            
                            
                                
                            
                        

                        
                            Content

                            
                                
                            
                        

                        
                            
                                Save
                            
                            
                                
                                    Delete
                                
                            
                        
                    
                ' or . = '
                    
                        

                        

                        
                            
                                Title

                                
                                    
                                        Created at: 01/09 2023 / 
                                        Modified at: 01/09 2023
                                        
                                    
                                
                            
                            
                            
                                Public
                                
                                    
                                
                            
                            
                                
                            
                        

                        
                            Content

                            
                                
                            
                        

                        
                            
                                Save
                            
                            
                                
                                    Delete
                                
                            
                        
                    
                ')]</value>
      <webElementGuid>462a8a48-7ead-46db-a1d1-5bd8e3784059</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
