<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Note 3</name>
   <tag></tag>
   <elementGuidId>7f8994e3-eb72-4c1c-9735-5874daaa28e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Note 3')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>7836821f-e269-408f-bfc8-92e3ef42f035</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=24</value>
      <webElementGuid>91cb3417-fb12-4295-bba9-c79d17476c88</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Note 3</value>
      <webElementGuid>65dd7160-2b2d-4b6d-a3d0-a60fd2d9507c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-2&quot;]/aside[@class=&quot;menu&quot;]/ul[@class=&quot;menu-list&quot;]/li[3]/a[1]</value>
      <webElementGuid>a27e0fd4-625f-449f-b8e2-4496654614e1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Note 3')]</value>
      <webElementGuid>3d7d1753-eb22-4c9a-928f-82586ec3bcbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 2'])[1]/following::a[1]</value>
      <webElementGuid>795728b3-14e0-44cd-8a3d-2f2948318d35</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 1'])[1]/following::a[2]</value>
      <webElementGuid>88b2a03b-7e20-4998-a29f-b5e11d1c728e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 4'])[1]/preceding::a[1]</value>
      <webElementGuid>d3374d01-1197-4e41-b9ec-baf1ab88015c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 5'])[1]/preceding::a[2]</value>
      <webElementGuid>39207c66-8d5b-4833-9a74-a839b65bcd3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Note 3']/parent::*</value>
      <webElementGuid>cb93c41b-9b1f-48de-902e-fb6d175d82cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=24')]</value>
      <webElementGuid>d6c0ba18-2ba3-462f-9cb7-cae8837a567e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a</value>
      <webElementGuid>ab121606-5120-4305-a0e8-0cca9d4030ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=24' and (text() = 'Note 3' or . = 'Note 3')]</value>
      <webElementGuid>8617f5b5-ccc8-47d1-bd9c-f2ecff6dfc0f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
