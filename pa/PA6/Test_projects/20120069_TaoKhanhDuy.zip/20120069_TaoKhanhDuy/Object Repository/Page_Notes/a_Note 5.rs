<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Note 5</name>
   <tag></tag>
   <elementGuidId>3bce435c-0865-4e9f-8dfa-db957b7808a3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Note 5')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>eee39bf0-af01-4e01-926b-e1f35c9e61fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=26</value>
      <webElementGuid>4e82d8bd-e03c-46ba-9691-0eb14fe3715e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Note 5</value>
      <webElementGuid>6df0642e-3157-469e-8f57-54a07a144cee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-2&quot;]/aside[@class=&quot;menu&quot;]/ul[@class=&quot;menu-list&quot;]/li[5]/a[1]</value>
      <webElementGuid>29fa6582-c7d9-44ac-ab29-88ed0e3daa7a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Note 5')]</value>
      <webElementGuid>f10591e9-89ca-4a96-9924-f8aca46046a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 4'])[1]/following::a[1]</value>
      <webElementGuid>19fc85eb-5b00-44f3-8c39-30d924249c1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 3'])[1]/following::a[2]</value>
      <webElementGuid>162f47fc-3176-47ae-aa1c-e1b6f5eabf23</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Note 5']/parent::*</value>
      <webElementGuid>b8b4893c-9640-4be1-acd3-d3f73b3b2fda</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=26')]</value>
      <webElementGuid>ec98e71b-3532-41b2-b225-cada1de312d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a</value>
      <webElementGuid>a91c2b18-d9a8-4063-ab92-896b0dc99f7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=26' and (text() = 'Note 5' or . = 'Note 5')]</value>
      <webElementGuid>d2e92b5d-1f66-49c4-9353-61b3e0370318</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
