<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Note 1</name>
   <tag></tag>
   <elementGuidId>e20b274a-a8d5-4ddc-ac59-a0dd42a8528a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>li > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Note 1')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2ac1aa30-9fdd-4b4d-a530-dae3d0ac5f22</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=22</value>
      <webElementGuid>2ec9b398-a356-4f79-a462-85991b5a0120</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Note 1</value>
      <webElementGuid>5deb5fdc-5556-4b39-aec2-f28b9e8b9ccc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/section[@class=&quot;section&quot;]/div[@class=&quot;columns&quot;]/div[@class=&quot;column is-2&quot;]/aside[@class=&quot;menu&quot;]/ul[@class=&quot;menu-list&quot;]/li[1]/a[1]</value>
      <webElementGuid>2dadce21-d996-4b15-a03b-4d77f2646e6b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Note 1')]</value>
      <webElementGuid>bb0b5359-6ef8-4ada-ba32-c0fff7c341ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New document'])[1]/following::a[1]</value>
      <webElementGuid>9beefa7f-b56d-494b-85dd-48bc6dbdc2b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::a[2]</value>
      <webElementGuid>ccade1f3-eeed-4351-b754-47d77fbaf7ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 2'])[1]/preceding::a[1]</value>
      <webElementGuid>e65e4e72-e3fe-49d5-8579-fcc305481928</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 3'])[1]/preceding::a[2]</value>
      <webElementGuid>8b4a5af4-f63a-4961-a361-9a09689f4d89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Note 1']/parent::*</value>
      <webElementGuid>bc3e3b62-df0d-450b-a141-e6670eaca79a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=22')]</value>
      <webElementGuid>7f1e1088-96b1-46b4-81cf-31efc4ad4fcf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li/a</value>
      <webElementGuid>64505174-23f9-4531-ae14-76b7b6635341</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=22' and (text() = 'Note 1' or . = 'Note 1')]</value>
      <webElementGuid>08ed10ae-f0a0-40d0-855f-7f027cff3e6e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
