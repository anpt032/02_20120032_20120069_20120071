<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_New document</name>
   <tag></tag>
   <elementGuidId>d436cead-04d4-4128-be61-981193a87582</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.navbar-end > a.navbar-item</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'New document')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bef5ffdc-64d3-4e1d-95ef-0ef5b140bc9f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/editor/?docid=0</value>
      <webElementGuid>01db011f-c18c-4d15-8084-2fc9e8829aaf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>navbar-item</value>
      <webElementGuid>435a050b-d6a8-4547-be38-dd7219364974</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>New document</value>
      <webElementGuid>e5e8a81e-7c1f-4c5a-be3c-89fd2b9f2eb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/nav[@class=&quot;navbar is-dark&quot;]/div[@class=&quot;navbar-menu&quot;]/div[@class=&quot;navbar-end&quot;]/a[@class=&quot;navbar-item&quot;]</value>
      <webElementGuid>6f3b05af-fdbd-4be4-b3a7-54cfa568641d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'New document')]</value>
      <webElementGuid>06ba2b98-c47b-4f47-840c-a14dd4fa44af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/following::a[1]</value>
      <webElementGuid>54d483d3-4c68-4c96-8e93-92c6418bbf03</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Note 1'])[1]/preceding::a[1]</value>
      <webElementGuid>09c3859e-058f-43e0-8547-57d98350c940</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='New document']/parent::*</value>
      <webElementGuid>ef78c25e-a6c6-4f2b-975c-82f72e99ba4d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/editor/?docid=0')]</value>
      <webElementGuid>ba5cced8-6ddb-4350-af1c-aaf3c7bbd142</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a</value>
      <webElementGuid>dce050ad-aa07-4c49-a972-1539de77b7c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/editor/?docid=0' and (text() = 'New document' or . = 'New document')]</value>
      <webElementGuid>e49ddba4-b0a0-4f0d-a9bc-ad21227d8885</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
