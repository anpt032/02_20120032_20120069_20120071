<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Order and check out multiple products</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>272a0761-190e-404d-a718-a650753e0235</testSuiteGuid>
   <testCaseLink>
      <guid>c9c2b585-4594-41e1-aefa-ef640f098124</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data-driven samples/Order and check out multiple products</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>ca2af0bc-270c-450a-918a-14af5dbe8a9e</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Product List</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId></testDataLinkId>
         <type>DEFAULT</type>
         <value></value>
         <variableId>e316e7e7-cde2-4ff4-84f7-e4519410ab7c</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
